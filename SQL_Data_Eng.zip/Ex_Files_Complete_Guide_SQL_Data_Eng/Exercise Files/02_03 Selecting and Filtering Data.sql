select name, price from products

select * from orders where total_amount>100

select * from customer where customer_name like 'A%'