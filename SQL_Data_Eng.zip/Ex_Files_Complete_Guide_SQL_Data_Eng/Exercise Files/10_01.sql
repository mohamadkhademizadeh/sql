select * from customer

select *  from customer where city = 'City1'

select *  from customer where city = 'City1'

select *  from customer where city  in ('City1', 'City2')

select avg(customer_name) from customer

select * from orders join customer on 