delete from products where product_id =7

delete from public."FruitJuice"

truncate public."FruitJuice"

drop table public."FruitJuice"