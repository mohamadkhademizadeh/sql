select * from products order by price 

select * from customer order by customer_name


select * from customer order by customer_name desc

select * from products order by price, name

select * from products where is not price>100  order by price